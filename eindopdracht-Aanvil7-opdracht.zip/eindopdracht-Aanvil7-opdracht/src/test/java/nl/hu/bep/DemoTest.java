package nl.hu.bep;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

//TODO: Deze class moet uiteraard weg zodra je zelf nuttige tests hebt geschreven!
public class DemoTest {
    @Test
    public void junitDoetHet() {
        assertEquals(2, 1 + 1);
    }
}
